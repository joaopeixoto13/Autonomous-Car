from ctypes.wintypes import HWINSTA
import cv2 as cv
import numpy as np
from utils import *

WIDTH = 640
HEIGHT = 480
CENTER_COORD = (WIDTH//2,HEIGHT-1)
font = cv.FONT_HERSHEY_COMPLEX
 
def imgProcess(img):
    img = cv.resize(img, (WIDTH,HEIGHT))                                                                # Resize image
    img = cv.cvtColor(img,cv.COLOR_RGB2GRAY)                                                            # Convert to grayscale
    img = cv.blur(img,(5,5))                                                                            # Blur image to remove noise
    _,img = cv.threshold(img,170,255,cv.THRESH_BINARY)                                                  # Threshold image
    img = cv.morphologyEx(img,cv.MORPH_BLACKHAT,(5,5))                                                  # Apply blackhat filter
    img = cv.morphologyEx(img,cv.MORPH_DILATE,(10,10))                                                  # Apply open filter
    horizontal_kernel = cv.getStructuringElement(cv.MORPH_RECT, (30,1))                                 # Create horizontal kernel
    horizontal_lines = cv.morphologyEx(img, cv.MORPH_CLOSE, horizontal_kernel, iterations=1)            # Apply horizontal filter in order to remove horizontal lines
    img = img - horizontal_lines                                                                        # Subtract horizontal lines from original image, leaving only the vertical and diagonal lines
    return img                                                                                          # Return image

def drawVirtualCircles(img, center, start_radius, end_radius, thick):
    for i in range (start_radius,end_radius+1,10):
        cv.ellipse(img,center,(i,i),0,15,165, color = 255, thickness= thick)
    return img

def trendLine(points):
    x = [i[0] for i in points]                                  # Create x array
    y = [i[1] for i in points]                                  # Create y array
    A = np.vstack([x, np.ones(len(x))]).T                       # Create A matrix
    m, c = np.linalg.lstsq(A, y,rcond=None)[0]                  # Solve for m and c
    return m,c                                                  # Return the slope (m) and y-intercept (c)

def drawTrendLine(slope, b, img,color):
    for i in range(0,WIDTH):                                    # Iterate over all x pixels in image
        y = slope * i + b                                       # Calculate y value for each x
        cv.line(img,(i,int(y)),(i,int(y)),color,1)              # Draw the corresponding line

def MeanFilter(u):                                            
    global n_array  
    global u_array 
    u_array = np.roll(u_array, -1, axis=0)                      # Roll array to the left
    u_array[4] = u                                              # Insert new value in array
    u_array = np.multiply(u_array, n_array)                     # Multiply array by n_array
    u_mean = np.sum(u_array)                                    # Sum array
    return u_mean                                               # Return mean value

def PIcontrol(u):                                               # PI control
    global error_sum                                            # Global error sum
    u = MeanFilter(u)                                           # Apply mean filter        
    error = 0 - u                                               # Calculate error
    error_sum = error_sum + error*Ki                            # Sum error                                            
    u = error*Kp + error_sum                                    # Calculate control signal        
    if (u > 45):                                                # Limit control signal
        u = 45                                      
    elif (u < -45):                                             # Limit control signal    
        u = -45                                                                     
    return u                                                    # Return control signal      

def separateArrayByRegion(points):  
    final_points = []
    in_region = False
    if(len(points) == 0 or len(points) > 300):                      # If there are no points or too many points, return empty array
        return final_points                                         # Return empty array
    points.sort(key=lambda x: x[0])                                 # Sort points by x coordinate
    final_points.append([points[0]])                                # Add first point to final array
    for point in points:                                            # Iterate over all points
        for region in final_points:                                 # Iterate over all regions
            for point_in_region in region:                          # Iterate over all points in region
                if euclideanDistance(point,point_in_region) < 200:  # If point is close to point in region
                    region.append(point)                            # Add point to region
                    in_region = True                                # Set flag to True
                    break                                           # Break inner loop
        if in_region == False:                                      # If point is not close to any region
            final_points.append([point])                            # Add point to new region
        in_region = False                                           # Reset flag

    return final_points                                             # Return final array
       
def detectLines(frame,cross_flag):                                  # Detect lines in image
    global n_lines

    imgA = imgProcess(frame)                                                    # Process image                                                   
    imgB = np.zeros((HEIGHT,WIDTH),dtype=np.uint8)                              # Create empty image

    if(cross_flag == False):                                                    # If cross flag is False
        drawVirtualCircles(imgB, (WIDTH//2,int(HEIGHT//2)), 70, 450, 2)  
    else:                                                                       # If cross flag is True
        drawVirtualCircles(imgB, (int(WIDTH//2),int(HEIGHT//3.3)), 30, 450, 2)  # Draw virtual circles               
    imgC = cv.bitwise_and(imgA, imgB)                                           # Apply bitwise and to get image with only lines        
    imgC,points = pointSelectionFilter(imgC,(1,1))                              # Select points in image
    final_contours = separateArrayByRegion(points)                              # Separate points by region

    n_lines = len(final_contours)                                               # Set number of lines to number of regions
    return imgC, n_lines, final_contours                                        # Return image with lines, number of lines and array of regions                                      

def trendLineAlgorithm(frame, priority):                                        # Trend line algorithm
    global u_k  
    global u_sum
    global u_inc
    global u   
    
    img, n_lines, final_contours = detectLines(frame,False)                                                         # Detect lines in image
    line_points = []                                                                                               

    if(n_lines > 0 and n_lines < 3):                                                                                # If there are less than 3 lines                                         
        for line_point in final_contours:                                                                                                                                                                                                                             
            line_point.sort(key=lambda x: x[0])                                                                     # Sort points by x coordinate                                                                       
            if(len(line_point) > 2):                                                                                # If there are more than 2 points in region                                                                 
                m,c = trendLine(line_point)                                                                         # Calculate trend line
                drawTrendLine(m,c,img,255)                                                                          # Draw trend line  
                line_points.append([line_point[0][0],line_point[0][1],line_point[-1][0],line_point[-1][1], m, c])   # Add points to array
        #cv.imshow("img",img)
        if (len(line_points) == 0):                                                                                 # If there are no points
            return 0                                                                                                # Return 0
        if (len(line_points) == 1):                                                                                 # If there is only one point
            if ((priority == PRIORITY_LEFT or priority == PRIORITY_AHEAD) and line_points[0][0] < WIDTH//2):        # If priority is left or ahead and line is on left side       
                top = (97 - line_points[0][5])/line_points[0][4] - WIDTH//2                                         # Calculate top     
                bottom = (HEIGHT - line_points[0][5])/line_points[0][4]                                             # Calculate bottom
                u = top*0.6+bottom*0.4                                                                              # Calculate control signal
                u_k = 0                                                                                             # Reset control signal     
            elif (priority == PRIORITY_RIGHT and line_points[0][3] > WIDTH//2):                                     # If priority is right and line is on right side  
                top = (97 - line_points[0][5])/line_points[0][4] - WIDTH//2                                         # Calculate top
                bottom = (HEIGHT - line_points[0][5])/line_points[0][4] - WIDTH                                     # Calculate bottom
                u = top*0.6+bottom*0.4                                                                              # Calculate control signal
                u_k = 0                                                                                             # Reset control signal                 
            else:                                                                                                   # If priority is left or right and line is on the oppsotive side (make the car turn smoothly in the correct direction)                        
                if (priority == PRIORITY_LEFT or priority == PRIORITY_AHEAD):                                       # If priority is left or ahead                          
                    u_k = u_k - u_inc                                                                               # Decrease control signal                                       
                    u = u_k * u_sum                                                                                 # Calculate control signal                                        
                else:                                                                                                  
                    u_k = u_k + u_inc                                                                               # Increase control signal                     
                    u = u_k * u_sum                                                                                 # Calculate control signal                       
        else:                                                                                                       # If there are 2 lines                                                                                                
            u = ((97 - line_points[0][5])/line_points[0][4])                                                        # Calculate control signal
            u2 = ((97 - line_points[1][5])/line_points[1][4])                                                       # Calculate control signal
            if ((u < WIDTH and u > 0 and u2 < WIDTH and u2 > 0) or ((u > WIDTH or u < 0) and (u2 > WIDTH or u2 < 0))):  # If both lines are in the image or both lines are out of the image
                u = u - WIDTH//2                                                                                    # Calculate control signal
                u2 = u2 - WIDTH//2                                                                                  # Calculate control signal
                u = u*0.5+u2*0.5                                                                                    # Calculate control signal
            else:                                                                                                   # Error case
                u = 0                                                                                               # Calculate control signal      
            u_k = 0                                                                                                 # Reset control signal
        
        u = PIcontrol(u)                                                                                            # Calculate PI control signal
        return u                                                                                                      
    return 0                                                                                                       

# Variables
PRIORITY_AHEAD = 0  
PRIORITY_RIGHT = 1
PRIORITY_LEFT = 2

n_lines = 0                                                                 # Number of lines detected
angle = 0                                                                   # Angle of car
m = 0                                                                       # Slope of line
c = 0                                                                       # Y-intercept of line
n_array = np.array([0.075, 0.075, 0.10, 0.25, 0.5])                         # Array of weights for mean filter
u_array =  np.array([0,0,0,0,0], dtype=float)                               # Array of control values
Kp = 0.2                                                                    # Proportional gain
Ki = 0.0                                                                    # Integral gain
error_sum = 0                                                               # Error sum
u = 0                                                                       # Control signal
contours = []                                                               # Contours
u_inc = 20                                                                  # Increment of control value
u_k = 0                                                                     # Control value
u_sum = (1 / Kp)                                                            # Sum of control values